
<?php $__env->startSection('title'); ?>
ESMS | Admin Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row container">
    <div class="col-md-5">
<table class="table table-striped ">
    <thead>
      <tr>
        <th scope="col">Username</th>
        <th scope="col">Email</th>
        <th scope="col">Edit</th>
        <th scope="col">Delete</th>
      </tr>
    </thead>
    <tbody>
        <?php if($data['admin']): ?>
      <tr>

        <th scope="row"><?php echo e($data['admin']->name); ?></th>
        <td><?php echo e($data['admin']->email); ?></td>

        <td>
          <input type="hidden" name="admin_id" value="<?php echo e($data['admin']->id); ?>"> 
          <a href="displayadmindetailspage/<?php echo e($data['admin']->id); ?>" class="btn btn-primary">Edit</a>
        </td>
       
        <td> 
          <a href="deleteadmindata/<?php echo e($data['admin']->id); ?>" class="btn btn-danger">Delete</a>
           </td>
      </tr>
      <?php endif; ?>

    </tbody>
  </table>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.masterlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ESS\resources\views/admin/admindashboard.blade.php ENDPATH**/ ?>