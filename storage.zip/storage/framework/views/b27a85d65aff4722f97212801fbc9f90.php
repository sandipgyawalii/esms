

<?php $__env->startSection('title'); ?>
    ESMS | GROUPS
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboard-title'); ?>
  Groups
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row container">
    <div class="col-md-5">
            <div class="card shadow-sm rounded-5">
            <div class="card-body ">
		<div class="container mt-4">

      <form action="" method="post">
    <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

         <h1 class="fs-4 card-title fw-bold mb-2"><?php echo e($value->group_name); ?> 
        
        </h1>
            <?php echo csrf_field(); ?>
            <div class="form-group mb-3">
                <label for="Name" class="text-muted">Enter Description</label>
                <input type="text" name="description" value=""  id="" 
                class="form-control w-100">
                <input type="hidden" name="id" value=""  id="" class="form-control w-100">

            </div>
            <div class="form-group  mb-3">
                <label for="paid by" class="text-muted">Paid by</label>
                <?php 
                $i=0
                ?>
<?php $__currentLoopData = $test; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $memberemail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault" name="paidby[]">
                    <label class="form-check-label" for="flexCheckDefault">
                      <?php echo e($memberemail); ?> 
 <a href="/user/deletemember/<?php echo e($memberemail); ?>/<?php echo e($value->id); ?>/<?php echo e($i); ?>">Delete Member</a>
                    </label>
                  </div>

                  <?php 
                  $i= $i+1
                   ?>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



            </div>
            <div class="form-group  mb-3">
              <label for="Total amount" class="text-muted">Total Amount</label>
              <input type="text" name="total-amount" value=""  id="" class="form-control w-100">
          </div>
            <div class="form-group  mb-3">
                <label for="date" class="text-muted">Date</label>
                <input type="date" name="date" value=""  id="" class="form-control w-100">
            </div>
            
            <button type="submit" class="btn btn-secondary mb-2 p-1" name="save">Save</button>

        </form>
       
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
</div>
    </div>
     <div class="col-md-5">
     <div class="card shadow-sm rounded-5">
        <div class="card-body ">
<div class="container mt-4">

    <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

     <h1 class="fs-4 card-title fw-bold mb-2">Edit Group</h1>
     <p class="text-warning">Click 'X' and press Edit button if you want to delete member</p>
    <form action="<?php echo e(url('user/updateuserdetails')); ?>" method="post">
        <?php echo csrf_field(); ?>

        <div class="form-group mb-3">
            <label for="Name" class="text-muted">Name</label>
        
            <input type="text" name="name" value="<?php echo e($value->group_name); ?>"  id="" 
            class="form-control w-100" placeholder="Enter new Group name">

        </div>
        <div class="form-group  mb-3">
            <label for="email" class="text-muted">Members Email</label>

            

            <input type="email"  data-role="taginput" name="email" id="" 
             value="<?php $__currentLoopData = $test; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $memberemail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($memberemail); ?><?php echo e(','); ?>

             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>"
             class="form-control w-100"placeholder="Add new member" >
            
        </div>
     
        
        <button type="submit" class="btn btn-secondary" name="editbtn">Edit</button>
        
    </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
</div>



    </div> 
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.usermasterlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ESS\resources\views/user/viewgroup.blade.php ENDPATH**/ ?>