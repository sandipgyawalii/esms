

<?php $__env->startSection('title'); ?>
ESMS | User Details
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row container">
    <div class="col-md-5">
        <table class="table table-striped">
            <thead>
              <tr>
                <th scope="col">Username</th>
                <th scope="col">Email</th>
                <th scope="col">Edit</th>
                <th scope="col">Delete</th>

              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td><?php echo e($row->name); ?></td>
                <td><?php echo e($row->email); ?></td>
                <form action="manage" method="post">
                <td>
                    <input type="hidden" name="user_id" value="<?php echo e($row->id); ?>">
                    <input type="submit" value="Edit" class="btn btn-primary">
                </td>
                <td>
                    <input type="submit" value="Delete" class="btn btn-danger">
                </td>
            </form>                
              </tr>
          
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
    </div>
</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.masterlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ESS\resources\views/admin/userdetails.blade.php ENDPATH**/ ?>