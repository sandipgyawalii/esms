

<?php $__env->startSection('title'); ?>
    ESMS | Groups
<?php $__env->stopSection(); ?>


<?php $__env->startSection('dashboard-title'); ?>
    Groups
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
      <div class="col-md-6 mt-2">
          <!-- Button trigger modal -->
    <button type="button" class="btn btn-warning mb-2 " data-bs-toggle="modal" data-bs-target="#exampleModal">
      Create Group
    </button>
    
    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Create Groups</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <div class="card shadow-sm rounded-5">
              <div class="card-body ">
          <div class="container mt-4">  
           <h1 class="fs-4 card-title fw-bold mb-2"></h1>
          <form action="<?php echo e(url('user/creategroup')); ?>" method="get">
              <?php echo csrf_field(); ?>
              <div class="form-group mb-3">
                  <label for="Group Name" class="text-muted">Group Name</label>
                  <input type="text" name="group_name" value=""  id="" 
                  class="form-control w-100">
                 
              <?php if($data['user']): ?>
                  <input type="hidden" name="user_id" value="<?php echo e($data['user']->id); ?>"  id="" class="form-control w-100">
  <?php endif; ?>
              </div>
              <div class="form-group  mb-3">
                  <label for="Members Email" class="text-muted">Members Email</label>
                  <input type="text" data-role="taginput" name="member_email[]" id=""  value="" class="form-control w-100">
              
              </div>
             
              
              
              

              <?php if($errors->any()): ?>
              <div class="danger">
                 <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <?php echo e($error); ?>

                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" name="create_group" class="btn btn-primary">Save </button>
      </div>
    </form>
        </div>
      </div>
    </div>
    <?php if(session('status')): ?>
    <div class="bg-info  rounded-5   p-1 mb-2 w-50 "><?php echo e(session('status')); ?></div>
      <?php endif; ?>

      <table class="table table-striped">
        <thead>
          <tr>
            <th scope="col">Groups Name</th>
            <th scope="col">Action</th>
            <th scope="col">Delete</th>




          </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $groupdetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($row->group_name); ?> 
              <span class=" bg-info bg-gradient text-dark rounded-circle p-1">14</span>       
                </td>  
          
            <td>
              <a href="/user/viewgroups/<?php echo e($row->id); ?>" class=""><i class="fa fa-lg fa-cog" aria-hidden="true"></i>

              </a> 
            </td>
            <td>
              <a href="/user/deletegroup/<?php echo e($row->id); ?>" class=""><i class="fa-lg fa fa-trash" aria-hidden="true"></i>
              </a> 
            </td>
            
           
          </tr>
      
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
              </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.usermasterlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ESS\resources\views/user/usergroup.blade.php ENDPATH**/ ?>