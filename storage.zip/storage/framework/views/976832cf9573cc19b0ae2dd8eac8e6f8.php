

<?php $__env->startSection('title'); ?>
    ESMS | Groups
<?php $__env->stopSection(); ?>


<?php $__env->startSection('dashboard-title'); ?>
    Groups
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-6">
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Optio alias incidunt laboriosam ducimus blanditiis recusandae! Eius repudiandae nesciunt excepturi hic, iure temporibus accusamus consectetur sunt voluptates dolores porro fuga enim.
        </div>

        <div class="col-md-6">
            <div class="row">
                <div class="col-md-9">
            
                    <div class="card shadow-sm rounded-5">
                        <div class="card-body ">
                    <div class="container mt-4">
            
                        <?php if(session('status')): ?>
                        <div class="bg-info p-3 rounded-5 ms-auto"> <?php echo e(session('status')); ?> </div>
                          <?php endif; ?>
                     <h1 class="fs-4 card-title fw-bold mb-2">Create Groups</h1>
                    <form action="<?php echo e(url('user/creategroup')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-group mb-3">
                            <label for="Group Name" class="text-muted">Group Name</label>
                            <input type="text" name="group_name" value=""  id="" 
                            class="form-control w-100">
                            <div class="danger">
                                <?php $__errorArgs = ['group_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        <?php if($data['user']): ?>
                            <input type="hidden" name="user_id" value="<?php echo e($data['user']->id); ?>"  id="" class="form-control w-100">
            <?php endif; ?>
                        </div>
                        <div class="form-group  mb-3">
                            <label for="Members Email" class="text-muted">Members Email</label>
                            <input type="text" data-role="taginput" name="member_email[]" id=""  value="" class="form-control w-100">
                        </div>
                       
                        
                        
                        <button type="submit" class="btn btn-secondary" name="create_group ">Create Group</button>
                    </form>
                </div>
            </div>
            </div>
        </div>
    </div>
    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.usermasterlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\ESS\resources\views/user/usergroup.blade.php ENDPATH**/ ?>