

<?php $__env->startSection('title'); ?>
    ESMS | User Details
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboard-title'); ?>
Details
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row container">
  <div class="col-md-8"></div>
  <?php if(session('status')): ?>
  <div class="bg-info p-3 rounded-5 ms-auto"> <?php echo e(session('status')); ?> </div>
    <?php endif; ?>

  <div class="col-md-5">
<table class="table table-striped ">
    <thead>
      <tr>
        <th scope="col">Username</th>
        <th scope="col">Email</th>
        <th scope="col">Edit</th>
        <th scope="col">Delete</th>
      </tr>
    </thead>
    <tbody>
        <?php if($userdata['user']): ?>
      <tr>

        <th scope="row"><?php echo e($userdata['user']->name); ?></th>
        <td><?php echo e($userdata['user']->email); ?></td>

        <td>
          
          <a href="<?php echo e(url('user/displayuserdetailspage')); ?>" class="btn btn-primary">Edit</a>
        </td>
       
        <td> 
          <a href="<?php echo e(url('user/deleteuserdetails')); ?>" class="btn btn-danger">Delete</a>
           </td>
      </tr>
      <?php endif; ?>

    </tbody>
  </table>
</div>
</div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.usermasterlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ESS\resources\views/user/userdetails.blade.php ENDPATH**/ ?>