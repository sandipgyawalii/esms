
<?php $__env->startSection('title'); ?>
ESMS | User Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboard-title'); ?>
Dashboard    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.usermasterlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\ESS\resources\views/user/userdashboard.blade.php ENDPATH**/ ?>